

public interface ActionListener {

}
