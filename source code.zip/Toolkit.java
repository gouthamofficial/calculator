

public class Toolkit {

    public static Object getDefaultToolkit() {
        return null;
    }

}
