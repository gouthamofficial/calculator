

public class Insets {

    public Insets(int i, int j, int k, int radius) {
    }

}
