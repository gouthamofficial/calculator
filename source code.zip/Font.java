

public class Font {

    public static final String BOLD = null;

}
