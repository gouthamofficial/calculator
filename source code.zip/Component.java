

public class Component {

}
